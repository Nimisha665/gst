import logo from './logo.svg';
import './App.css';
import GSTChecker from './GSTChecker';

function App() {
  return (
    <div className="App">
      <GSTChecker/>
    </div>
  );
}

export default App;
